const url = "https://raw.githubusercontent.com/Jdaoudd/NFL-Teams/main/NFL%20Teams.csv"
//accessed from code.org

const urlConference = getColumn(url, 1);
const urlDivision = getColumn(url, 2);
const urlTeam = getColumn(url, 3);
const urlCity = getColumn(url, 4);
const urlStadium = getColumn(url, 5);
const urlCapacity = getColumn(url, 6);
const urlCoach = getColumn(url, 7);
const urlImage = getColumn(url, 8);



function getTeam(selectedTeam){
  selectedTeam=selectedTeam.toLowerCase();
  var teams = [];
  for(var i in urlTeam){
    if (urlTeam[i].toLowerCase().includes(selectedTeam)){
      teams.push(urlConference[i]);
      teams.push(urlDivision[i]);
      teams.push(urlStadium[i]);
      teams.push(urlCapacity[i]);
      teams.push(urlCity[i]);
      teams.push(urlCoach[i]);
      teams.push(urlImage[i]);
    }
    }
  
  if (teams.length > 0){
    return teams;
  }
    
else{
  return "This team does not exist";
}
  
}
console.log(getTeam("COMMANDERS"));




function getColumn(url, columnNumber){
  var column = [];
  var table = [];
  var request = new XMLHttpRequest();  
  request.open("GET", url, false);   
  request.send(null);  
  var csvData = new Array();
  var jsonObject = request.responseText.split(/\r?\n|\r/);
  for (var i = 0; i < jsonObject.length; i++) {
    csvData.push(jsonObject[i].split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/));
  }
  table = csvData;
  column = getCol(table, columnNumber);
  return column;
}

//returns the specified column from a 2D Array
function getCol(matrix, col){
       var column = [];
       for(var i=1; i<matrix.length-1; i++){
          column.push(matrix[i][col]);
       }
       return column;
    }



